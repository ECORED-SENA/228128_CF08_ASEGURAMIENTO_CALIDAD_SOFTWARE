function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ThFU3zLxda":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

